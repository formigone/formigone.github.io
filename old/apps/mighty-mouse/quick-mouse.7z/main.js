var com = com || {};
com.OpenBook = {};

com.OpenBook.t = function(pScreenId, pTimerShellId, pLevelShellId, pLevel)
{
	this.screen = document.querySelector("#" + pScreenId);
	this.timerShell = document.querySelector("#" + pTimerShellId);
	this.levelShell = document.querySelector("#" + pLevelShellId);
	this.clearedBlocks = [];
	this.totalCleared = 0;
	this.level = pLevel;
	this.maxBlocks = parseInt(this.level * 1.5);
	this.timer = [0, 0, 0];
	this.stopTimer = false;
};


com.OpenBook.t.prototype.timeDown = function()
{
	this.timer[2]--;
	if (this.timer[2] < 0)
	{
		this.timer[2] = 59;
		this.timer[1]--;
	}
	
	if (this.timer[1] < 0)
	{
		timer[1] = 59;
		timer[0]--;
	}
	
	if (this.timer[0] < 0)
		this.timer[0] = 0;
};

com.OpenBook.t.prototype.showTimer = function()
{
	if (this.stopTimer)
		return;

	this.timeDown();
	
	if (this.timer[0] > 0 || this.timer[1] > 0 || this.timer[2] > 0)
	{
		this.timerShell.innerText = this.getTimer();
		var self = this;
	
		setTimeout(function(){
			self.showTimer();
		}, 20);
	}
	else
	{
		this.timerShell.innerText = this.getTimer();
		this.stopTimer = true;
		this.timeOut();
	}
};
	
com.OpenBook.t.prototype.getTimer = function()
{
	return 	(this.timer[0] < 10 ? ("0" + this.timer[0]) : this.timer[0]) + ":" + 
			(this.timer[1] < 10 ? ("0" + this.timer[1]) : this.timer[1]) + ":" + 
			(this.timer[2] < 10 ? ("0" + this.timer[2]) : this.timer[2]);
};

com.OpenBook.t.prototype.timeOut = function()
{
	this.totalCleared = -999999;
	this.maxBlocks = 999999;
	this.alert("Timeout!", 5000, function(){});
}
	
com.OpenBook.t.prototype.clearAll = function()
{
	for (var i = 0; i < this.maxBlocks; i++)
		this.screen.removeChild(document.querySelector("#__blocks_" + i + "__"));
		
	this.totalCleared = 0;
};

com.OpenBook.t.prototype.alert = function(pMsg, pTimeout, pCallback)
{
	var el = document.createElement("h1");
	el.classList.add("comOpenBook_alert");
	el.innerText = pMsg;
	
	document.body.appendChild(el);
	
	
	setTimeout(function(){
		document.body.removeChild(el);
		pCallback();
	}, pTimeout);
};

com.OpenBook.t.prototype.isAllClear = function()
{
	if (this.maxBlocks == this.totalCleared)
	{
		var self = this;
		this.stopTimer = true;
		
		this.alert("Level Cleared!", 2500, function(){
			self.clearAll();
			self.level++;
			self.maxBlocks = parseInt(self.level * 1.5);
			self.init();
		});
	}
};

com.OpenBook.t.prototype.clearBlock = function(pEl, self)
{
	var id = pEl.id.match(/__blocks_(\d+)__/);

	if (self.clearedBlocks[id[1]] == 0)
	{
		self.clearedBlocks[id[1]] = 1
		pEl.classList.add("comOpenBook_block_inset");
		pEl.classList.remove("comOpenBook_block_red");
		
		self.totalCleared++;
		self.isAllClear();
	}
};

com.OpenBook.t.prototype.init = function()
{
	var self = this;
	this.stopTimer = false;
	
	var sec = parseInt(5 + this.level * 0.15);
	
	this.timer = [parseInt(sec / 60), sec % 60, 0];

	for (var i = 0, block; i < this.maxBlocks; i++)
	{
		block = document.createElement("div");
		block.classList.add("comOpenBook_block");
		block.classList.add("comOpenBook_block_red");
		block.style.left = parseInt(Math.random() * (this.screen.clientWidth - 25)) + "px";
		block.style.top = parseInt(Math.random() * (this.screen.clientHeight - 25)) + "px";
		block.id = "__blocks_" + i + "__";
		
		block.addEventListener("mouseover", function(){
			self.clearBlock(this, self);
		});
		
		this.screen.appendChild(block);
		this.clearedBlocks[i] = 0;
	}
	
	this.showTimer();
	this.levelShell.innerText = this.level;
};


com.OpenBook.main = function(pScreenId, pTimerShellId, pLevelShellId, pLevel)
{
	var obj = new com.OpenBook.t(pScreenId, pTimerShellId, pLevelShellId, pLevel);
	obj.init();
};
